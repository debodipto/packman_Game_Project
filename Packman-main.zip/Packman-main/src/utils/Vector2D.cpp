#include "Vector2D.h"

Vector2D::Vector2D(float x, float y, float z) : x(x), y(y), z(z) {}
