#pragma once

struct Vector2D {
    float x, y, z;

    Vector2D(float x = 0, float y = 0, float z = 0);
};
