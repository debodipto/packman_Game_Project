#pragma once

#include "../Renderer.h"

class GameOverScreen {
public:
    void render(Renderer& renderer, int score);
};