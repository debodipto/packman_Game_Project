#pragma once

#include "../Renderer.h"

class PauseScreen {
public:
    void render(Renderer& renderer);
};