#pragma once

#include "../Renderer.h"

class Menu {
public:
    void render(Renderer& renderer);
    void renderControls(Renderer& renderer);
};